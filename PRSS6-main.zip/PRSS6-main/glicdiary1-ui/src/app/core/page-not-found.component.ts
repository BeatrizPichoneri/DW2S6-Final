import { Component } from '@angular/core';

@Component({
  selector: 'app-page-not-found',
  template: `
  <div class="container">
    <h1 class="text-center">Página não encontrada</h1>
  </div>
`,
  styles: [
  ]
})
export class PageNotFoundComponent {

}
