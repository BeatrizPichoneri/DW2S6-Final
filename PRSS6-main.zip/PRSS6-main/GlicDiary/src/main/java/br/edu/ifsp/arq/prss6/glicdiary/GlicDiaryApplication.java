package br.edu.ifsp.arq.prss6.glicdiary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlicDiaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlicDiaryApplication.class, args);
	}

}
