package br.edu.ifsp.arq.prss6.glicdiary.service.exception;

public class NonExistentOrInactiveUserException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
