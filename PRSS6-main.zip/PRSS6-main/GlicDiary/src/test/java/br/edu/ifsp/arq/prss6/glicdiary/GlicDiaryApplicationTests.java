package br.edu.ifsp.arq.prss6.glicdiary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlicDiaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
