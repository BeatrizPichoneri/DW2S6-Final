package br.edu.ifsp.arq.pprss6.diarioglicemico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiarioGlicemico1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
