package br.edu.ifsp.arq.prss6.glicdiary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Glicdiary {

	public static void main(String[] args) {
		SpringApplication.run(Glicdiary.class, args);
	}

}
